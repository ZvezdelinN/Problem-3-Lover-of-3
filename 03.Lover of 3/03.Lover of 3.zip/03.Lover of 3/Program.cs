﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace _03.Lover_of_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputMatriksDimentions = Console.ReadLine();
            string[] eachDimention = inputMatriksDimentions.Split(new char[]{' '},StringSplitOptions.RemoveEmptyEntries);

            int dimentionRow = int.Parse(eachDimention[0]);
            int dimentionColumn=int.Parse(eachDimention[1]);

            int[,] arrayOfNumbers = new int[dimentionRow, dimentionColumn];
            int counter1 = 0;
            int counter2 = 0;

            for (int i = 0; i < dimentionColumn; i++)
            {
                counter2 += counter1 / dimentionRow;
                counter1 = 0;
                for (int j = dimentionRow - 1; j >= 0; j--)
                {

                    arrayOfNumbers[j, i] = counter2 + counter1;
                    counter1 += 3;
                }
            }


            string enterNumberOfInstructions = Console.ReadLine();
            int numberOfInstruction = int.Parse(enterNumberOfInstructions);

            List<string> instructions = new List<string>();

            for (int i = 0; i < numberOfInstruction; i++)
            {
                instructions.Add(Console.ReadLine());
            }

            int row = dimentionRow - 1;
            int column = 0;
            int totalsum = arrayOfNumbers[row, column];



            foreach (string singleInstruction in instructions)
            {
                string[] partOfSingleInstruction = singleInstruction.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                int repeat = int.Parse(partOfSingleInstruction[1]);

                if (partOfSingleInstruction[0] == "UR" || partOfSingleInstruction[0] == "RU")
                {
                    for (int i = 1; i < repeat; i++)
                    {
                        
                        row--;
                        column++;
                        if (row < 0 || column > dimentionColumn - 1)
                        {
                            if(row==-1)
                            {
                                row++;
                                column--;
                            }
                            else if (column == -1)
                            {
                                row++;
                                column--;
                            }
                            continue;
                        }
                        totalsum += arrayOfNumbers[row, column];
                        arrayOfNumbers[row, column] = 0;
                    }
                }

                else if (partOfSingleInstruction[0] == "UL" || partOfSingleInstruction[0] == "LU")
                {
                    for (int i = 1; i < repeat; i++)
                    {
                       
                        row--;
                        column--;
                        if (row < 0 || column < 0)
                        {
                            if (row == -1)
                            {
                                row++;
                                column++;
                            }
                            else if (column == -1)
                            {
                                row++;
                                column++;
                            }
                            break;
                        }
                        totalsum += arrayOfNumbers[row, column];
                        arrayOfNumbers[row, column] = 0;
                    }
                }

                else if (partOfSingleInstruction[0] == "LD" || partOfSingleInstruction[0] == "DL")
                {
                    for (int i = 1; i < repeat; i++)
                    {
                       
                        row++;
                        column--;
                        if (row > dimentionRow - 1 || column < 0)
                        {
                            if (row == -1)
                            {
                                row--;
                                column++;
                            }
                            else if (column == -1)
                            {
                                row--;
                                column++;
                            }
                            break;
                        }
                        totalsum += arrayOfNumbers[row, column];
                        arrayOfNumbers[row, column] = 0;
                    }
                }

                else if (partOfSingleInstruction[0] == "DR" || partOfSingleInstruction[0] == "RD")
                {
                    for (int i = 1; i < repeat; i++)
                    {
                        
                        row++;
                        column++;
                        if (row > dimentionRow - 1 || column > dimentionColumn - 1)
                        {
                            if (row == -1)
                            {
                                row--;
                                column--;
                            }
                            else if (column == -1)
                            {
                                row--;
                                column--;
                            }
                            break;
                        }
                        totalsum += arrayOfNumbers[row, column];
                        arrayOfNumbers[row, column] = 0;
                    }
                }
            }

            Console.Write(totalsum);

        }
    }
}
