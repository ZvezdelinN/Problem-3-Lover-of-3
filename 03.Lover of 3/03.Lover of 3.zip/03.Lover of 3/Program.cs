﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace _03.Lover_of_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputMatriksDimentions = Console.ReadLine();
            string[] eachDimention = inputMatriksDimentions.Split(new char[]{' '},StringSplitOptions.RemoveEmptyEntries);

            long dimentionRow = long.Parse(eachDimention[0]);
            long dimentionColumn = long.Parse(eachDimention[1]);

            //if ((dimentionRow < 1  || dimentionRow > 1000)|| (dimentionColumn > 750 || dimentionColumn < 1))
            //{
            //    Console.WriteLine("Wrong max value for the dimentions of the matrix");
            //    return;
            //}

            long[,] arrayOfNumbers = new long[dimentionRow, dimentionColumn];
            long counter1 = 0;
            long counter2 = 0;

            for (int i = 0; i < dimentionColumn; i++)
            {
                counter2 += counter1 / dimentionRow;
                counter1 = 0;
                for (int j = (int)dimentionRow - 1; j >= 0; j--)
                {

                    arrayOfNumbers[j, i] = counter2 + counter1;
                    counter1 += 3;
                }
            }


            string enterNumberOfInstructions = Console.ReadLine();
            long numberOfInstruction = long.Parse(enterNumberOfInstructions);

            //if (numberOfInstruction < 1 || numberOfInstruction > 1000)
            //{
            //    Console.WriteLine("The number of the instructions must be [1-1000]");
            //    return;
            //}

            List<string> instructions = new List<string>();

            for (int i = 0; i < numberOfInstruction; i++)
            {
                instructions.Add(Console.ReadLine());
            }

            long row = dimentionRow - 1;
            long column = 0;
            long totalsum = arrayOfNumbers[row, column];



            foreach (string singleInstruction in instructions)
            {
                string[] partOfSingleInstruction = singleInstruction.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                long repeat = long.Parse(partOfSingleInstruction[1]);

                //if (repeat < 1 || repeat > 1000)
                //{
                //    Console.WriteLine("The number of the repeat must be [1-1000]");
                //    return;
                //}

                if (partOfSingleInstruction[0] == "UR" || partOfSingleInstruction[0] == "RU")
                {
                    for (int i = 1; i < repeat; i++)
                    {
                        
                        row--;
                        column++;
                        if (row < 0 || column > dimentionColumn - 1)
                        {
                            row++;
                            column--;
                        
                            continue;
                        }
                        totalsum += arrayOfNumbers[row, column];
                        arrayOfNumbers[row, column] = 0;
                    }
                }

                else if (partOfSingleInstruction[0] == "UL" || partOfSingleInstruction[0] == "LU")
                {
                    for (int i = 1; i < repeat; i++)
                    {
                       
                        row--;
                        column--;
                        if (row < 0 || column < 0)
                        {
                           row++;
                           column++;

                           continue;
                        }
                        totalsum += arrayOfNumbers[row, column];
                        arrayOfNumbers[row, column] = 0;
                    }
                }

                else if (partOfSingleInstruction[0] == "LD" || partOfSingleInstruction[0] == "DL")
                {
                    for (int i = 1; i < repeat; i++)
                    {
                       
                        row++;
                        column--;
                        if (row > dimentionRow - 1 || column < 0)
                        {
                            row--;
                            column++;

                            continue;
                        }
                        totalsum += arrayOfNumbers[row, column];
                        arrayOfNumbers[row, column] = 0;
                    }
                }

                else if (partOfSingleInstruction[0] == "DR" || partOfSingleInstruction[0] == "RD")
                {
                    for (int i = 1; i < repeat; i++)
                    {
                        
                        row++;
                        column++;
                        if (row > dimentionRow - 1 || column > dimentionColumn - 1)
                        {
                            row--;
                            column--;

                            continue;
                        }
                        totalsum += arrayOfNumbers[row, column];
                        arrayOfNumbers[row, column] = 0;
                    }
                }
            }

            Console.Write(totalsum);

        }
    }
}
